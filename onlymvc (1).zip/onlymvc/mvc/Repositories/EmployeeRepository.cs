using mvc.Models;
using Npgsql;
namespace mvc.Repositories;
public class EmployeeRepository : IEmployeeRepository
{
    private readonly NpgsqlConnection conn;
    public EmployeeRepository(IConfiguration config)
    {
        conn = new NpgsqlConnection(config.GetConnectionString("GroupA"));
    }

    public void AddEmployee(EmployeeModel employee)
    {
        try
        {
            conn.Open();
            var query = "insert into t_employeemaster(c_name,c_gender,c_dob,c_shift,c_department,c_image) values(@n,@g,@d,@s,@de,@i)";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@n", employee.c_name);
            command.Parameters.AddWithValue("@g", employee.c_gender);
            command.Parameters.AddWithValue("@d", employee.c_dob);
            command.Parameters.AddWithValue("@s", employee.c_shift);
            command.Parameters.AddWithValue("@de", employee.c_department);
            command.Parameters.AddWithValue("@i", employee.c_image);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);

        }
        finally
        {
            conn.Close();
        }
    }

    public void DeleteEmployee(int id)
    {
        try
        {
            conn.Open();
            var query = "delete from t_employeemaster where c_id=@id";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@id", id);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    public List<DepartmentModel> GetDepartments()
    {
        try
        {
            conn.Open();
            var query = "select * from t_departments";
            var command = new NpgsqlCommand(query, conn);
            var reader = command.ExecuteReader();
            var departments = new List<DepartmentModel>();
            while (reader.Read())
            {
                var department = new DepartmentModel();
                department.c_id = reader.GetInt32(0);
                department.c_name = reader.GetString(1);
                departments.Add(department);
            }
            return departments;
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return null;
    }

    public EmployeeModel GetEmployee(int id)
    {
        try
        {
            conn.Open();
            var query = "select * from t_employeemaster where c_id=@id";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@id", id);
            var reader = command.ExecuteReader();
            if (reader.Read())
            {
                var employee = new EmployeeModel();
                employee.c_id = reader.GetInt32(0);
                employee.c_name = reader.GetString(1);
                employee.c_gender = reader.GetString(2);
                employee.c_dob = reader.GetDateTime(3);
                employee.c_shift = (string[])reader["c_shift"];
                employee.c_department = reader.GetInt32(5);
                employee.c_image = reader.GetString(6);
                return employee;
            }

        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return null;
    }

    public EmployeeModel GetEmployeeFromUsername(string username)
    {
        try
        {
            conn.Open();
            var query = "select * from t_employeemaster where c_name=@username";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@username", username);
            var reader = command.ExecuteReader();
            if (reader.Read())
            {
                var employee = new EmployeeModel();
                employee.c_id = reader.GetInt32(0);
                employee.c_name = reader.GetString(1);
                employee.c_gender = reader.GetString(2);
                employee.c_dob = reader.GetDateTime(3);
                employee.c_shift = (string[])reader["c_shift"];
                employee.c_department = reader.GetInt32(5);
                employee.c_image = reader.GetString(6);
                return employee;
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return null;
    }

    

    public List<EmployeeModel> GetEmployees()
    {
        try
        {
            conn.Open();
            var query = "select * from t_employeemaster order by c_id desc";
            var command = new NpgsqlCommand(query, conn);
            var reader = command.ExecuteReader();
            var employees = new List<EmployeeModel>();
            while (reader.Read())
            {
                var employee = new EmployeeModel();
                employee.c_id = reader.GetInt32(0);
                employee.c_name = reader.GetString(1);
                employee.c_gender = reader.GetString(2);
                employee.c_dob = reader.GetDateTime(3);
                employee.c_shift = (string[])reader["c_shift"];
                employee.c_department = reader.GetInt32(5);
                employee.c_image = reader.GetString(6);
                employees.Add(employee);
            }
            return employees;
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return null;
    }

    public void UpdateEmployee(EmployeeModel employee)
    {
        try
        {
            conn.Open();
            var query = "update t_employeemaster set c_name=@n, c_gender = @g, c_dob = @d, c_shift = @s, c_department = @de, c_image = @i where c_id = @id";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@n", employee.c_name);
            command.Parameters.AddWithValue("@g", employee.c_gender);
            command.Parameters.AddWithValue("@d", employee.c_dob);
            command.Parameters.AddWithValue("@s", employee.c_shift);
            command.Parameters.AddWithValue("@de", employee.c_department);
            command.Parameters.AddWithValue("@i", employee.c_image);
            command.Parameters.AddWithValue("@id", employee.c_id);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }

    }
}