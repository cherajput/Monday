using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using mvc.Models;
using mvc.Repositories;

namespace mvc.Controllers;

public class EmployeeAjaxController : Controller
{
    private readonly ILogger<EmployeeAjaxController> _logger;
    private readonly IUserRepository _userRepository;
    private readonly IEmployeeRepository _employeeRepository;

    public EmployeeAjaxController(ILogger<EmployeeAjaxController> logger, IUserRepository userRepository, IEmployeeRepository employeeRepository)
    {
        _logger = logger;
        _userRepository = userRepository;
        _employeeRepository = employeeRepository;
    }

    [SessionAuthorize]
    public IActionResult Index()
    {
        return View();
    }
    [SessionAuthorize]
    public IActionResult GetData()
    {
        var username = HttpContext.Session.GetString("username");
        var employees = _employeeRepository.GetEmployeeFromUsername(username);
        return Json(employees);

    }
    [SessionAuthorize]
    public IActionResult Create()
    {
        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View();
    }
    [SessionAuthorize]
    [HttpPost]
    public IActionResult Create([FromForm] EmployeeModel employee)
    {

        if (employee.Image != null)
        {
            var path = "wwwroot/images/" + employee.Image.FileName;
            using (var stream = new FileStream(path, FileMode.Create))
            {
                employee.Image.CopyTo(stream);
            }
            employee.c_image = employee.Image.FileName;
        }

        _employeeRepository.AddEmployee(employee);
        return RedirectToAction("index");
    }
    [SessionAuthorize]
    [HttpGet]
    public IActionResult Edit()
    {

        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View();
    }
    [SessionAuthorize]
    public IActionResult GetEmployee(int id)
    {
        var employee = _employeeRepository.GetEmployee(id);
        return Json(employee);
    }
    [SessionAuthorize]
    [HttpPost]
    public IActionResult Edit([FromForm] EmployeeModel employee)
    {
        var oldEmployee = _employeeRepository.GetEmployee(employee.c_id.Value);
        if (employee.Image != null)
        {
            var path = "wwwroot/images/" + employee.Image.FileName;
            using (var stream = new FileStream(path, FileMode.Create))
            {
                employee.Image.CopyTo(stream);
            }
            employee.c_image = employee.Image.FileName;
        }
        else
        {
            employee.c_image = oldEmployee.c_image;
        }
        employee.c_shift = oldEmployee.c_shift;
        employee.c_department = oldEmployee.c_department;
        _userRepository.UpdateUsername(employee.c_name);
        _employeeRepository.UpdateEmployee(employee);

        return Ok("index");
    }
    [SessionAuthorize]
    public IActionResult Delete(int id)
    {
        _employeeRepository.DeleteEmployee(id);
        return Ok("index");
    }
    [SessionAuthorize]
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
