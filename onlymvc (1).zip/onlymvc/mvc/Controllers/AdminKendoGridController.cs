using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using mvc.Models;
using mvc.Repositories;

namespace mvc.Controllers;

public class AdminKendoGridController : Controller
{
    private readonly ILogger<AdminKendoGridController> _logger;
    private readonly IUserRepository _userRepository;
    private readonly IEmployeeRepository _employeeRepository;

    public AdminKendoGridController(ILogger<AdminKendoGridController> logger, IUserRepository userRepository, IEmployeeRepository employeeRepository)
    {
        _logger = logger;
        _userRepository = userRepository;
        _employeeRepository = employeeRepository;
    }

    [SessionAuthorize]
    public IActionResult Index()
    {
        return View();
    }
    [SessionAuthorize]
    public IActionResult GetDepartments()
    {
        var departments = _employeeRepository.GetDepartments();
        return Json(departments);
    }
    [SessionAuthorize]
    public IActionResult GetData()
    {
        var employees = _employeeRepository.GetEmployees();
        return Json(employees);
    }
    public static string file = "";
    [SessionAuthorize]
    [HttpPost]
    public IActionResult UploadPhoto(EmployeeModel city)
    {
        if (city.Image != null)
        {
            string filename = city.Image.FileName;
            //convert filename to unique using guid
            filename = Guid.NewGuid() + filename;
            string filepath = "wwwroot/images/" + filename;

            using (var stream = new FileStream(filepath, FileMode.Create))
            {

                city.Image.CopyTo(stream);
            }

            file = filename;

        }

        return Json(new { filename = file });
    }
    [SessionAuthorize]
    public IActionResult Create()
    {
        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View();
    }
    [SessionAuthorize]
    [HttpPost]
    public IActionResult Create(EmployeeModel employee)
    {

        employee.c_image = file;
        _employeeRepository.AddEmployee(employee);
        return Json("index");
    }
    [SessionAuthorize]
    [HttpGet]
    public IActionResult Edit()
    {

        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View();
    }
    [SessionAuthorize]
    public IActionResult GetEmployee(int id)
    {
        var employee = _employeeRepository.GetEmployee(id);
        return Json(employee);
    }
    [SessionAuthorize]
    [HttpPost]
    public IActionResult Edit(EmployeeModel employee)
    {
        employee.c_image = file;
        _employeeRepository.UpdateEmployee(employee);
        return Json("index");
    }
    [SessionAuthorize]
    [HttpPost]
    public IActionResult Delete(int id)
    {
        _employeeRepository.DeleteEmployee(id);
        return Ok("index");
    }
    [SessionAuthorize]
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
