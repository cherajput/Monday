using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using mvc.Models;
using mvc.Repositories;

namespace mvc.Controllers;

public class AdminController : Controller
{
    private readonly ILogger<AdminController> _logger;
    private readonly IUserRepository _userRepository;
    private readonly IEmployeeRepository _employeeRepository;

    public AdminController(ILogger<AdminController> logger, IUserRepository userRepository, IEmployeeRepository employeeRepository)
    {
        _logger = logger;
        _userRepository = userRepository;
        _employeeRepository = employeeRepository;
    }

    [SessionAuthorize]
    public IActionResult Index()
    {
        var employees = _employeeRepository.GetEmployees();
        return View(employees);
    }

    [SessionAuthorize]
    public IActionResult KendoIndex()
    {
        var employees = _employeeRepository.GetEmployees();
        return View(employees);
    }
    [SessionAuthorize]
    public IActionResult Create()
    {
        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View();
    }
    [SessionAuthorize]
    public IActionResult KendoCreate()
    {
        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View();
    }
    [SessionAuthorize]
    [HttpPost]
    public IActionResult Create(EmployeeModel employee)
    {
        //select last index of employee.shift




        if (employee.Image != null)
        {
            var uniqueFileName = Guid.NewGuid().ToString() + "_" + employee.Image.FileName;
            var path = "wwwroot/images/" + uniqueFileName;
            using (var stream = new FileStream(path, FileMode.Create))
            {
                employee.Image.CopyTo(stream);
            }
            employee.c_image = uniqueFileName;
        }

        _employeeRepository.AddEmployee(employee);
        return RedirectToAction("index");
    }
    [SessionAuthorize]
    public IActionResult Edit(int id)
    {
        var employee = _employeeRepository.GetEmployee(id);
        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View(employee);
    }
    [SessionAuthorize]
    public IActionResult KendoEdit(int id)
    {
        var employee = _employeeRepository.GetEmployee(id);
        var departments = _employeeRepository.GetDepartments();
        ViewBag.Departments = new SelectList(departments, "c_id", "c_name");
        return View(employee);
    }
    [SessionAuthorize]
    [HttpPost]
    public IActionResult Edit(EmployeeModel employee)
    {
        if (employee.Image != null)
        {
            //convert image name into unique name by adding guid
            var uniqueFileName = Guid.NewGuid().ToString() + "_" + employee.Image.FileName;

            var path = "wwwroot/images/" + uniqueFileName;
            using (var stream = new FileStream(path, FileMode.Create))
            {
                employee.Image.CopyTo(stream);
            }
            employee.c_image = uniqueFileName;
        }
        else
        {
            var oldEmployee = _employeeRepository.GetEmployee(employee.c_id.Value);
            employee.c_image = oldEmployee.c_image;
        }
        _employeeRepository.UpdateEmployee(employee);
        return RedirectToAction("index");
    }
    [SessionAuthorize]
    public IActionResult Delete(int id)
    {
        _employeeRepository.DeleteEmployee(id);
        return RedirectToAction("index");
    }

    [SessionAuthorize]
    public IActionResult GetDepartment()
    {
        var departments = _employeeRepository.GetDepartments();
        return Json(departments);
    }
    
    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
