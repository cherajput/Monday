using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http;

namespace mvc.Controllers;
public class SessionAuthorizeAttribute : TypeFilterAttribute
{
    public SessionAuthorizeAttribute() : base(typeof(SessionAuthorizeFilter))
    {
    }
}

public class SessionAuthorizeFilter : IAuthorizationFilter
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public SessionAuthorizeFilter(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        // Check if username exists in session
        string username = _httpContextAccessor.HttpContext.Session.GetString("username");

        if (string.IsNullOrEmpty(username))
        {
            // Redirect to login page or return unauthorized response
            context.Result = new RedirectToActionResult("Login", "User", null);
        }
    }
}
