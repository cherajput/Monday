    namespace mvc.Models;
    public class EmployeeModel
    {
        //id,name,gender,dob,shift,department,image
        public int? c_id { get; set; }
        public string? c_name { get; set; }
        public string? c_gender { get; set; }
        public DateTime c_dob { get; set; }
        public string[]? c_shift { get; set; }
        public int? c_department { get; set; }
        public string? c_image { get; set; }
        public IFormFile? Image { get; set; }
    }