using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Login.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Tomm.Models;

namespace Tomm.Controllers
{
    [Route("[controller]")]
    public class LoginController : Controller
    {
        private readonly ILogger<LoginController> _logger;
        private readonly ILoginRepository _loginRepository;

        public LoginController(ILogger<LoginController> logger, ILoginRepository loginRepository)
        {
            _logger = logger;
            _loginRepository = loginRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(LoginModel login)
        {
            if(_loginRepository.Login(login))
            {
                if(HttpContext.Session.GetString("c_roles")=="admin")
                {
                    return RedirectToAction ("Index", "Home");
                }
                else if(HttpContext.Session.GetString("c_roles")=="user")
                {
                    return RedirectToAction ("Privacy", "Home");
                }
                else
                {
                    return RedirectToAction ("Index", "Home");
                }
            }
            else 
            {
              return RedirectToAction ("Index", "Home");   
            }
            
        }
    }
}