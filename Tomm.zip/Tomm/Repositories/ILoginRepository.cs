using Tomm.Models;

namespace Login.Repositories
{
    public interface ILoginRepository
    {
        public bool Login (LoginModel login);
    }
}