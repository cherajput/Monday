using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using sunday1_1.Models;
using sunday1_1.Repositories;

namespace sunday1_1.Controllers
{
    //[Route("[controller]")]
    public class StudentController : Controller
    {
        private readonly ILogger<StudentController> _logger;

        private readonly IStudentRepository _studentRepository;


        public StudentController(ILogger<StudentController> logger, IStudentRepository studentRepository)
        {
            _logger = logger;
            _studentRepository = studentRepository;
        }
       

        public ActionResult Index()
        {
            var students = _studentRepository.GetStudents();
            return View(students);
        }

         public ActionResult IndexKendo()
        {
            var students = _studentRepository.GetStudents();
            return View(students);
        }
        


        [HttpGet]
        public IActionResult AddStudent()
        {
            var departments = _studentRepository.GetDepartments();
            ViewBag.Departments = departments;
            return View();

            
        }

          [HttpGet]
        public IActionResult AddStudentKendo()
        {
            var departments = _studentRepository.GetDepartments();
            ViewBag.Departments = departments;
            return View();

            
        }

        [HttpPost]
        public IActionResult AddStudent(StudentModel student)
        {
             if (student.Image != null)
        {
            var path = "wwwroot/images/" + student.Image.FileName;
            using (var stream = new FileStream(path, FileMode.Create))
            {
                student.Image.CopyTo(stream);
            }
            student.c_image = student.Image.FileName;
        }
            _studentRepository.AddStudent(student);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult AddStudentKendo(StudentModel student)
        {
             if (student.Image != null)
        {
            var path = "wwwroot/images/" + student.Image.FileName;
            using (var stream = new FileStream(path, FileMode.Create))
            {
                student.Image.CopyTo(stream);
            }
            student.c_image = student.Image.FileName;
        }
            _studentRepository.AddStudent(student);
            return RedirectToAction("IndexKendo");
        }

        public IActionResult Edit(int id)
        {
            var student = _studentRepository.GetStudent(id);
            var departments = _studentRepository.GetDepartments();
            ViewBag.Departments = departments;
            return View(student);
        }

          public IActionResult EditKendo(int id)
        {
            var student = _studentRepository.GetStudent(id);
            var departments = _studentRepository.GetDepartments();
            ViewBag.Departments = departments;
            return View(student);
        }

        [HttpPost]
        public IActionResult Edit(StudentModel student)
        {
         if (student.Image != null)
            {
                var path = "wwwroot/images/" + student.Image.FileName;
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    student.Image.CopyTo(stream);
                }
                student.c_image = student.Image.FileName;
            }
            else
            {
                student.c_image = student.c_image;
            }
            
            _studentRepository.UpdateStudent( student);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult EditKendo(StudentModel student)
        {
         if (student.Image != null)
            {
                var path = "wwwroot/images/" + student.Image.FileName;
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    student.Image.CopyTo(stream);
                }
                student.c_image = student.Image.FileName;
            }
            else
            {
                student.c_image = student.c_image;
            }
            
            _studentRepository.UpdateStudent( student);
            return RedirectToAction("IndexKendo");
        }

      
        public IActionResult Delete(int id)
        {
            _studentRepository.DeleteStudent(id);
            return RedirectToAction("Index");
        }

         public IActionResult DeleteKendo(int id)
        {
            _studentRepository.DeleteStudent(id);
            return RedirectToAction("IndexKendo");
        }





        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}