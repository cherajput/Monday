using Npgsql;
using sunday1_1.Models;

namespace sunday1_1.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        private readonly NpgsqlConnection conn;
        
        public StudentRepository(IConfiguration configuration)
        {
            conn = new NpgsqlConnection(configuration.GetConnectionString("Kali"));
        }

        public void AddStudent(StudentModel student)
        {
            try
            {
                conn.Open();
                string query = "insert into public.t_student(c_name, c_email, c_department, c_course, c_image, c_phone, c_dob) values(@n, @e, @d, @c, @i, @p, @dob)";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("n", student.c_name);
                cmd.Parameters.AddWithValue("e", student.c_email);
                cmd.Parameters.AddWithValue("d", student.c_department);
                cmd.Parameters.AddWithValue("c", student.c_course);
                cmd.Parameters.AddWithValue("i", student.c_image);
                cmd.Parameters.AddWithValue("p", student.c_phone);
                cmd.Parameters.AddWithValue("dob", student.c_dob);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public List<StudentModel>GetStudents()
        {
            try
            {
                conn.Open();
                string query = "select * from public.t_student inner join public.t_department on public.t_student.c_department = public.t_department.c_id";
                var cmd = new NpgsqlCommand(query, conn);
                var reader = cmd.ExecuteReader();
                var students = new List<StudentModel>();
                while (reader.Read())
                {
                    var student = new StudentModel();
                    
                        student.c_id = reader.GetInt32(0);
                        student.c_name = reader.GetString(1);
                        student.c_email = reader.GetString(2);
                        student.c_department = reader.GetInt32(3);
                        student.c_course = (string[])reader["c_course"];
                        student.c_image = reader.GetString(5);
                        student.c_phone = reader.GetString(6);
                        student.c_dob = reader.GetDateTime(7);
                        student.c_department_name = reader.GetString(9);
                        students.Add(student);
           
                }
                return students;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
               
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public List<DepartmentModel> GetDepartments()
        {
            try
            {
                conn.Open();
                string query = "select * from public.t_department";
                var cmd = new NpgsqlCommand(query, conn);
                var reader = cmd.ExecuteReader();
                var departments = new List<DepartmentModel>();
                while (reader.Read())
                {
                    var department = new DepartmentModel();
                    department.c_id = reader.GetInt32(0);
                    department.c_department = reader.GetString(1);
                    departments.Add(department);
                }
                return departments;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public StudentModel GetStudent(int id)
        {
            try
            {
                conn.Open();
                string query = "select * from public.t_student where c_id = @id";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("id", id);
                var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    var student = new StudentModel();
                    student.c_id = reader.GetInt32(0);
                    student.c_name = reader.GetString(1);
                    student.c_email = reader.GetString(2);
                    student.c_department = reader.GetInt32(3);
                    student.c_course = (string[])reader["c_course"];
                    student.c_image = reader.GetString(5);
                    student.c_phone = reader.GetString(6);
                    student.c_dob = reader.GetDateTime(7);
                    return student;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        public void UpdateStudent( StudentModel student)
        {
            try
            {
                conn.Open();
                string query = "update public.t_student set c_name = @n, c_email = @e, c_department = @d, c_course = @c, c_image = @i, c_phone = @p, c_dob = @dob where c_id = @id";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("n", student.c_name);
                cmd.Parameters.AddWithValue("e", student.c_email);
                cmd.Parameters.AddWithValue("d", student.c_department);
                cmd.Parameters.AddWithValue("c", student.c_course);
                cmd.Parameters.AddWithValue("i", student.c_image);
                cmd.Parameters.AddWithValue("p", student.c_phone);
                cmd.Parameters.AddWithValue("dob", student.c_dob);
                cmd.Parameters.AddWithValue("id", student.c_id);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public void DeleteStudent(int id)
        {
            try
            {
                conn.Open();
                string query = "delete from public.t_student where c_id = @id";
                var cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        
    }
}