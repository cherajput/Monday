using Npgsql;
using sunday1_1.Models;

namespace sunday1_1.Repositories
{
    public interface IStudentRepository
    {
        void AddStudent(StudentModel student);
        List<StudentModel> GetStudents();
        public StudentModel GetStudent(int id);
        public void UpdateStudent( StudentModel student);
        public void DeleteStudent(int id);

        public List<DepartmentModel> GetDepartments();

    }
}