namespace sunday1_1
{
    public class DepartmentModel
    {
        public int c_id { get; set; }
        public string c_department { get; set; }
    }
}