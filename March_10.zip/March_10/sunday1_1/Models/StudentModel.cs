namespace sunday1_1.Models
{
    public class StudentModel
    {
        public int c_id { get; set; }
        public string c_name { get; set; }
        public string c_email { get; set; }
        public int c_department { get; set; }
        public string[] c_course { get; set; }
        public string? c_image { get; set; }
        public string c_phone { get; set; }
        public IFormFile? Image { get; set; }
        public DateTime c_dob { get; set; }
        public string c_department_name { get; set; }
    }
}