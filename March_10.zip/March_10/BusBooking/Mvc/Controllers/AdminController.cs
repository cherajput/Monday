using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Booking.Models;
using Booking.Repositories;

namespace Mvc.Controllers
{
    //[Route("[controller]")]
    public class AdminController : Controller
    {
        private readonly ILogger<AdminController> _logger;

        private readonly IAdminRepository _adminRepository;

        public AdminController(ILogger<AdminController> logger, IAdminRepository adminRepository)
        {
            _logger = logger;
            _adminRepository = adminRepository;
        }
        

        public IActionResult Index()
        {
            var trips = _adminRepository.GetTrips();
            return View(Index);
        }

        public IActionResult Trips()
        {
            var trips = _adminRepository.GetTrips();
            return View(trips);
        }

    [HttpGet]
    public IActionResult AddTrip()
    {
        return View();
    }

    [HttpPost]
    public IActionResult AddTrip(TripModel trip)
    {
        if (ModelState.IsValid)
        {
            _adminRepository.AddTrip(trip);
            return RedirectToAction("Trips");
        }

        return View(trip);
    }

   [HttpGet]
    public IActionResult Delete(int id)
    {
        _adminRepository.DeleteTrip(id);
        return RedirectToAction("Trips");
    }
    
     [HttpGet]
    public IActionResult Edit(int id)
    {
        var trip = _adminRepository.GetTrip(id);
        if (trip == null)
        {
            return NotFound();
        }

        return View(trip);
    }

    [HttpPost]
    public IActionResult UpdateTrip(TripModel trip)
    {
        if (ModelState.IsValid)
        {
            _adminRepository.UpdateTrip(trip);
            return RedirectToAction("Trips");
        }

        return View("Edit", trip);
    }
    

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}