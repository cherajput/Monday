using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Booking.Models;
using Booking.Repositories;


namespace Booking.Controllers
{
    //[Route("[controller]")]
    public class UserController : Controller
    {
        private readonly ILogger<UserController> _logger;

        private readonly IUserRepository _userRepository;

        public UserController(ILogger<UserController> logger, IUserRepository userRepository)
        {
            _logger = logger;
            _userRepository = userRepository;
        }
        

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(UserModel user)
        {
           if(!_userRepository.IsUser(user.c_email))
            {
                _userRepository.AddUser(user);
                return RedirectToAction("Login");
            }
            else
            {
                ViewBag.msg = "User already exists";
                return View();
            }
           
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(UserModel user)
        {
        if (_userRepository.Login(user))
            {
                if (HttpContext.Session.GetString("userrole") == "admin")
                {
                    return RedirectToAction("Trips", "Admin");
                }
                else if (HttpContext.Session.GetString("userrole") == "user")
                {

                    return RedirectToAction("Bookings", "Customer");
                }
            }

            else
            {
                return Ok("wrong");
            }
            return Ok("wrong");
        }

        [HttpGet]
         public IActionResult KendoLogin()
        {
            return View();
        }

        [HttpPost]
        public IActionResult KendoLogin(UserModel user)
        {
        if (_userRepository.Login(user))
            {
                if (HttpContext.Session.GetString("userrole") == "admin")
                {
                    return RedirectToAction("KendoLogin", "User");
                }
                else if (HttpContext.Session.GetString("userrole") == "user")
                {

                    return RedirectToAction("KendoRegister", "User");
                }
            }

            else
            {
                return Ok("wrong");
            }
            return Ok("wrong");
        }


        [HttpGet]
        public IActionResult KendoRegister()
        {
            return View();
        }

        [HttpPost]
        public IActionResult KendoRegister(UserModel user)
        {
            if(!_userRepository.IsUser(user.c_email))
            {
                _userRepository.AddUser(user);
                return RedirectToAction("KendoLogin", "User");
            }
            else
            {
                ViewBag.msg = "User already exists";
                return View();
            }
           
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}