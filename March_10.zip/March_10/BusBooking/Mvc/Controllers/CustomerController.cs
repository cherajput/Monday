using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Booking.Models;
using Booking.Repositories;


namespace Mvc.Controllers
{
    //[Route("[controller]")]
    public class CustomerController : Controller
    {
        private readonly ILogger<CustomerController> _logger;
        private readonly ICustomerRepository _bookingRepository;

      

       
            
   
        public CustomerController(ILogger<CustomerController> logger, ICustomerRepository bookingRepository)
        {
            _logger = logger;
            _bookingRepository = bookingRepository;
           
        }

        public IActionResult Index()
        {
            return View();
        }

    


    [HttpGet]
    public IActionResult Bookings()
    {
        var bookings = _bookingRepository.GetBookings();
        return View(bookings);
    }

            [HttpGet]
    public IActionResult AddBooking()
    {
        
        return View();
    }

    [HttpPost]
    public IActionResult AddBooking(BookModel booking)
    {
        if (ModelState.IsValid)
        {
            _bookingRepository.AddBooking(booking);
            return RedirectToAction("Bookings");
        }

        return View(booking);
    }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}




