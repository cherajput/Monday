namespace Booking.Models
{
    public class BookModel
    {
        public int c_id { get; set; }
        public string c_select_trip { get; set; }
        public DateTime c_date_trip { get; set; }
        public int c_prize_trip { get; set; }
        public int c_available_ticket { get; set; }
        public int c_ticket_quantity { get; set; }
        public int c_total_cost { get; set; }
    }
}