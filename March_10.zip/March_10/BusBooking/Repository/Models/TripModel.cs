namespace Booking.Models
{
    public class TripModel
    {
        public int c_id { get; set; }
        public string c_trip { get; set; }
        public string c_prize { get; set; }
        public int c_tstock { get; set; }
        public int c_cstock { get; set; }
    }
}