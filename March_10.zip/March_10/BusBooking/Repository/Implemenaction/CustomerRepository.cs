using Npgsql;
using Booking.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace Booking.Repositories
{
    public class CustomerRepository : ICustomerRepository 
    {
        private NpgsqlConnection conn;
        private readonly IHttpContextAccessor httpContextAccessor;

        public CustomerRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            conn = new NpgsqlConnection(configuration.GetConnectionString("Kali"));
            this.httpContextAccessor = httpContextAccessor;
        }

         

            public void AddBooking(BookModel booking)
                {
                    try
                    {
                        conn.Open();
                        string query = "insert into public.t_book(c_select_trip, c_date_trip, c_prize_trip, c_available_ticket, c_ticket_quantity, c_total_cost) values (@c_select_trip, @c_date_trip, @c_prize_trip, @c_available_ticket, @c_ticket_quantity, @c_total_cost)";
                        var command = new NpgsqlCommand(query, conn);
                        command.Parameters.AddWithValue("@c_select_trip", booking.c_select_trip);
                        command.Parameters.AddWithValue("@c_date_trip", booking.c_date_trip);
                        command.Parameters.AddWithValue("@c_prize_trip", booking.c_prize_trip);
                        command.Parameters.AddWithValue("@c_available_ticket", booking.c_available_ticket);
                        command.Parameters.AddWithValue("@c_ticket_quantity", booking.c_ticket_quantity);
                        command.Parameters.AddWithValue("@c_total_cost", booking.c_total_cost);

                        command.ExecuteNonQuery();
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }

                public List<BookModel> GetBookings()
                {
                    List<BookModel> bookings = new List<BookModel>();
                    try
                    {
                        conn.Open();
                        string query = "select * from public.t_book";
                        var command = new NpgsqlCommand(query, conn);
                        var reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            BookModel booking = new BookModel();
                            booking.c_id = reader.GetInt32(0);
                            booking.c_select_trip = reader.GetString(1);
                            booking.c_date_trip = reader.GetDateTime(2);
                            booking.c_prize_trip = reader.GetInt32(3);
                            booking.c_available_ticket = reader.GetInt32(4);
                            booking.c_ticket_quantity = reader.GetInt32(5);
                            booking.c_total_cost = reader.GetInt32(6);
                            bookings.Add(booking);
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                    return bookings;
                }


            

    }
}
