using Npgsql;
using Booking.Models;
using Microsoft.Extensions.Configuration;

namespace Booking.Repositories
{
    public class AdminRepository : IAdminRepository 
    {
        private NpgsqlConnection conn;

        public AdminRepository(IConfiguration configuration)
        {
            conn = new NpgsqlConnection(configuration.GetConnectionString("Kali"));
        }

        public void AddTrip(TripModel trip)
        {
            try
            {
                conn.Open();
                string query = "insert into public.t_trip(c_trip,c_prize,c_tstock,c_cstock) values(@t,@p,@ts,@cs)";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@t", trip.c_trip);
                command.Parameters.AddWithValue("@p", trip.c_prize);
                command.Parameters.AddWithValue("@ts", trip.c_tstock);
                command.Parameters.AddWithValue("@cs", trip.c_cstock);

                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public List<TripModel> GetTrips()
        {
            List<TripModel> trips = new List<TripModel>();
            try
            {
                conn.Open();
                string query = "select * from public.t_trip";
                var command = new NpgsqlCommand(query, conn);
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    TripModel trip = new TripModel();
                    trip.c_id = reader.GetInt32(0);
                    trip.c_trip = reader.GetString(1);
                    trip.c_prize = reader.GetString(2);
                    trip.c_tstock = reader.GetInt32(3);
                    trip.c_cstock = reader.GetInt32(4);
                    trips.Add(trip);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return trips;
        }

        public TripModel GetTrip(int id)
        {
            TripModel trip = new TripModel();
            try
            {
                conn.Open();
                string query = "select * from public.t_trip where c_id=@id";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@id", id);
                var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    trip.c_id = reader.GetInt32(0);
                    trip.c_trip = reader.GetString(1);
                    trip.c_prize = reader.GetString(2);
                    trip.c_tstock = reader.GetInt32(3);
                    trip.c_cstock = reader.GetInt32(4);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return trip;
        }

        public void UpdateTrip(TripModel trip)
        {
            try
            {
                conn.Open();
                string query = "update public.t_trip set c_trip=@t,c_prize=@p,c_tstock=@ts,c_cstock=@cs where c_id=@id";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@t", trip.c_trip);
                command.Parameters.AddWithValue("@p", trip.c_prize);
                command.Parameters.AddWithValue("@ts", trip.c_tstock);
                command.Parameters.AddWithValue("@cs", trip.c_cstock);
                command.Parameters.AddWithValue("@id", trip.c_id);

                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public void DeleteTrip(int id)
        {
            try
            {
                conn.Open();
                string query = "delete from public.t_trip where c_id=@id";
                var command = new NpgsqlCommand(query, conn);
                command.Parameters.AddWithValue("@id", id);

                command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }
    }
}