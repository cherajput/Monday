using Npgsql;
using Booking.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;




namespace Booking.Repositories;

public class UserRepository : IUserRepository
{
        private NpgsqlConnection conn;
        private readonly IHttpContextAccessor httpContextAccessor;


        public UserRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            conn = new NpgsqlConnection(configuration.GetConnectionString("Kali"));
            this.httpContextAccessor = httpContextAccessor;

        }

    // public void AddUser(UserModel user)
    // {
    //     try
    //     {

          
    //         conn.Open();

    //         string query = "insert into public.t_user(c_username,c_email,c_password,c_roles) values(@u,@e,@p,'user')";
    //         var command = new NpgsqlCommand(query, conn);
    //         command.Parameters.AddWithValue("@u", user.c_username);
    //         command.Parameters.AddWithValue("@e", user.c_email);
    //         command.Parameters.AddWithValue("@p", user.c_password);

    //         command.ExecuteNonQuery();


    //     }
    //     catch (Exception e)
    //     {
    //         Console.WriteLine(e.Message);
    //     }
    //     finally
    //     {
    //         conn.Close();
    //     }
    // }

    public void AddUser(UserModel user)
    {
        try
        {
            conn.Open();
            string query = "insert into public.t_user(c_username,c_email,c_password,c_roles) values(@u,@e,@p,'user')";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@u", user.c_username);
            command.Parameters.AddWithValue("@e", user.c_email);
            command.Parameters.AddWithValue("@p", user.c_password);
            command.ExecuteNonQuery();
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    public bool IsUser(string email)
    {
        try
        {
            conn.Open();
            string query = "select * from public.t_user where c_email=@email";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@email", email);
            var reader = command.ExecuteReader();

            // Check if there is at least one row in the result set
            if (reader.Read())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return false;
    }

    public bool Login(UserModel user)
    {
        try
        {
            conn.Open();
            string query = "select * from public.t_user where c_email = @email";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@email", user.c_email);
            // command.Parameters.AddWithValue("@password", user.c_password);

            var rows = command.ExecuteReader();
            if (rows.Read())
            {

                

                    string username = rows["c_username"].ToString();
                    string role = rows["c_roles"].ToString();
                    httpContextAccessor.HttpContext.Session.SetInt32("userid", rows.GetInt32(0));
                    httpContextAccessor.HttpContext.Session.SetString("userrole", role);
                    httpContextAccessor.HttpContext.Session.SetString("useremail", user.c_email);
                    httpContextAccessor.HttpContext.Session.SetString("username", username);

                    return true;
                }
               
            else
            {
                return false;
            }

        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);

        }
        finally
        {
            conn.Close();
        }
        return false;
    }


    










}