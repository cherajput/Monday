using Booking.Models;
namespace Booking.Repositories;

public interface IUserRepository
{
    public void AddUser(UserModel user);
    public bool IsUser(string email);
    public bool Login(UserModel user);


}