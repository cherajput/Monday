using Booking.Models;

namespace Booking.Repositories
{
    public interface IAdminRepository
    {
        void AddTrip(TripModel trip);
        public List<TripModel> GetTrips();
        public TripModel GetTrip(int id);
        void UpdateTrip(TripModel trip);
        void DeleteTrip(int id);
       
        
    }
}