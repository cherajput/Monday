using Booking.Models;
using System;
using System.Collections.Generic;

namespace Booking.Repositories
{
    public interface ICustomerRepository
    {
        void AddBooking(BookModel book);
        public List<BookModel> GetBookings();

       



    }
}