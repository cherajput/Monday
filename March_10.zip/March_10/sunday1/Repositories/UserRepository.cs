using Npgsql;
using sunday1.Models;
using Microsoft.AspNetCore.Identity;



namespace sunday1.Repositories;

public class UserRepository : IUserRepository
{
    private readonly string _conn;
    private readonly NpgsqlConnection conn;
    private NpgsqlConnection connForTask;
    private readonly IHttpContextAccessor access;
    public UserRepository(IConfiguration config, IHttpContextAccessor accessor)
    {
        _conn = config.GetConnectionString("Kali");
        conn = new NpgsqlConnection(_conn);
        connForTask = new NpgsqlConnection(_conn);
        access = accessor;
    }

    public void AddUser(UserModel user)
    {
        try
        {

            var hasher = new PasswordHasher<UserModel>();
            user.c_password = hasher.HashPassword(user, user.c_password);
            conn.Open();

            string query = "insert into public.t_user(c_username,c_email,c_password,c_roles) values(@u,@e,@p,'employee')";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@u", user.c_username);
            command.Parameters.AddWithValue("@e", user.c_email);
            command.Parameters.AddWithValue("@p", user.c_password);

            command.ExecuteNonQuery();


        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
    }

    public bool IsUser(string email)
    {
        try
        {
            conn.Open();
            string query = "select * from public.t_user where c_email=@email";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@email", email);
            var reader = command.ExecuteReader();

            // Check if there is at least one row in the result set
            if (reader.Read())
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
        }
        finally
        {
            conn.Close();
        }
        return false;
    }

    public bool Login(UserModel user)
    {
        try
        {
            conn.Open();
            string query = "select * from public.t_user where c_email = @email";
            var command = new NpgsqlCommand(query, conn);
            command.Parameters.AddWithValue("@email", user.c_email);
            // command.Parameters.AddWithValue("@password", user.c_password);

            var rows = command.ExecuteReader();
            if (rows.Read())
            {

                if (VerifyPassword(rows["c_password"].ToString(), user.c_password))
                {

                    string username = rows["c_username"].ToString();
                    string role = rows["c_roles"].ToString();
                    access.HttpContext.Session.SetInt32("userid", rows.GetInt32(0));
                    access.HttpContext.Session.SetString("userrole", role);
                    access.HttpContext.Session.SetString("useremail", user.c_email);
                    access.HttpContext.Session.SetString("username", username);

                    return true;
                }
                else
                {
                    return false;
                }



            }
            else
            {
                return false;
            }

        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);

        }
        finally
        {
            conn.Close();
        }
        return false;
    }


    public bool VerifyPassword(string storedHash, string providedPassword)
    {
        var passwordHasher = new PasswordHasher<UserModel>();
        var result = passwordHasher.VerifyHashedPassword(null, storedHash, providedPassword);

        return result == PasswordVerificationResult.Success;
    }







}