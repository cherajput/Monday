

using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using practice.Models;
using practice.Repositories;

namespace practice.Controllers;

public class ItemController : Controller
{
    private readonly ILogger<ItemController> _logger;
    private readonly IItemRepository _ItemRepository;

    public ItemController(ILogger<ItemController> logger, IItemRepository itemRepository)
    {
        _logger = logger;
        _ItemRepository = itemRepository;
    }
    [HttpGet]
    public IActionResult Index()
    {
        return View();
    }
    [HttpPost]
    public IActionResult Index( ItemModel add)
    {
        if(add.Image != null && add.Image.Length > 0)
        {
            var uniquefilename = Guid.NewGuid() + "_" + add.Image.FileName;
            var filepath = Path.Combine("wwwroot", "uploads", uniquefilename);

            using (var stream = System.IO.File.Create(filepath))
            {
                add.Image.CopyTo(stream);
            }

            add.c_image = uniquefilename;
        }
        _ItemRepository.Additem(add);
        return RedirectToAction ("Index", "Home");
    }

    [HttpGet]    
    public IActionResult show()
    {
        var items = _ItemRepository.GetItems(); // Assuming _repository is your repository instance
        return View(items);
    }
    


    
}
