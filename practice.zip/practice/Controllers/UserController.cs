

using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using practice.Models;
using practice.Repositories;

namespace practice.Controllers;

public class UserController : Controller
{
    private readonly ILogger<UserController> _logger;
    private readonly IRegisterRepository _registerRepository;

    public UserController(ILogger<UserController> logger, IRegisterRepository registerRepository)
    {
        _logger = logger;
        _registerRepository = registerRepository;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Index(UserModel login)
    {
        if(_registerRepository.Login(login))
        {
            if(HttpContext.Session.GetString("c_roles")=="admin")
            {
                return RedirectToAction ("Index","Home");
            }
            else if(HttpContext.Session.GetString("c_roles")=="user")
            {
                return RedirectToAction ("Index","Item");
            }
            else
            {
                return RedirectToAction("Index");
            }       
        }
        else
        {
            return View();
        }
    }


    
}
