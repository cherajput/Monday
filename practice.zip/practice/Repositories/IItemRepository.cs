using practice.Models;

namespace practice.Repositories
{
    public interface IItemRepository
    {
        public void Additem(ItemModel add);

        public List<ItemModel> GetItems();
    }
}