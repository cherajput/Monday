using practice.Models;

namespace practice.Repositories
{
    public interface IRegisterRepository
    {
        public bool Login (UserModel login);
    }
}