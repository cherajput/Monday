using Npgsql;
using NpgsqlTypes;
using practice.Models;

namespace practice.Repositories
{
    public class ItemRepository : IItemRepository
    {
        private readonly string _conn;
        private readonly NpgsqlConnection conn;
        private readonly IHttpContextAccessor access;

        public ItemRepository(IConfiguration configuration, IHttpContextAccessor accessor)
        {
            _conn =configuration.GetConnectionString("Kali");
            conn = new NpgsqlConnection(_conn);
            access = accessor;
        }

        public void Additem(ItemModel add)
        {
            try
            {
                conn.Open();
                string query ="insert into t_items(c_name,c_category,c_image,c_cost_per_unit,c_initial_stock,c_available_stock) values (@n,@c,@i,@cpu,@is,@as)";
                NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@n", add.c_name);
                cmd.Parameters.AddWithValue("@c", add.c_category);
                cmd.Parameters.AddWithValue("@i", add.c_image);
                // cmd.Parameters.Add(new NpgsqlParameter("@i", NpgsqlDbType.Bytea) { Value = add.c_image });
                cmd.Parameters.AddWithValue("@cpu", add.c_cost_per_unit);
                cmd.Parameters.AddWithValue("@is", add.c_initial_stock);
                cmd.Parameters.AddWithValue("@as", add.c_available_stock);
                cmd.ExecuteNonQuery();


            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public List<ItemModel> GetItems()
        {
            List<ItemModel> items = new List<ItemModel>();
            try
            {
                conn.Open();
                string query =" select * from t_items";
                NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
                var rows = cmd.ExecuteReader();
                while(rows.Read())
                {
                    ItemModel item = new ItemModel();
                    item.c_id = rows.GetInt32(0);
                    item.c_name = rows.GetString(1);
                    item.c_category = rows.GetString(2);
                    item.c_image = rows.GetString(3);
                    item.c_cost_per_unit = rows.GetInt32(4);
                    item.c_available_stock = rows.GetInt32(5);
                    item.c_initial_stock = rows.GetInt32(6);
                    items.Add(item);
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
                return items;
        }

        

    }
}