using Npgsql;
using practice.Models;

namespace practice.Repositories
{
    public class RegisterRepositories : IRegisterRepository
    {
        private readonly string _conn;
        private readonly NpgsqlConnection conn;
        private readonly IHttpContextAccessor access;

        public RegisterRepositories(IConfiguration configuration, IHttpContextAccessor accessor)
        {
            _conn = configuration.GetConnectionString("Kali");
            conn = new NpgsqlConnection(_conn);
            access = accessor;
            
        }

        public bool Login(UserModel login)
        {
            try
            {
                conn.Open();
                string query = "select * from t_login where c_email=@c_email And c_password=@c_password";
                NpgsqlCommand cmd = new NpgsqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@c_email", login.c_email);
                cmd.Parameters.AddWithValue("@c_password", login.c_password);
                var rows = cmd.ExecuteReader();

                if(rows.Read())
                {
                    string c_email = rows["c_email"].ToString();
                    string c_roles = rows["c_roles"].ToString();

                    access.HttpContext.Session.SetString("c_email",c_email);
                    access.HttpContext.Session.SetString("c_roles",c_roles);

                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                conn.Close();
            }
            return true;
        }
    }
}